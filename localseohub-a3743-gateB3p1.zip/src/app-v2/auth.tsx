import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { destinationFor, returnPathFromLocation } from './returnTo';
import { useOnboardingStatus } from '../hooks/useOnboardingStatus';
import { LoadingState } from '../components/ui';
import { supabase } from '../lib/supabase';

async function signOutAndRestart() {
  await supabase.auth.signOut().catch(() => undefined);
  window.location.assign('/');
}

const SKELETON = (
  <div className="min-h-screen bg-v2-bg-primary flex items-center justify-center font-v2">
    <LoadingState message="Comprobando tu sesión..." />
  </div>
);

const ERROR_SCREEN = (
  <div className="min-h-screen bg-v2-bg-primary flex items-center justify-center font-v2 px-4">
    <div className="text-center max-w-sm">
      <h1 className="text-v2-xl font-bold text-v2-text-primary mb-2">Error de conexión</h1>
      <p className="text-v2-sm text-v2-text-secondary mb-6">
        No se pudo comprobar tu progreso. Comprueba tu conexión e inténtalo de nuevo.
      </p>
      <button
        onClick={() => window.location.reload()}
        className="inline-flex items-center justify-center px-6 py-3 rounded-v2-lg bg-v2-primary-600 hover:bg-v2-primary-700 text-white font-semibold text-v2-sm transition-colors shadow-v2-sm"
      >
        Reintentar
      </button>
      <button
        type="button"
        onClick={() => { void signOutAndRestart(); }}
        className="block mx-auto mt-4 text-v2-sm text-v2-text-secondary hover:text-v2-text-primary underline underline-offset-2 transition-colors"
      >
        Cerrar sesión
      </button>
    </div>
  </div>
);

/**
 * Protects app routes (/hoy, /plan, etc.).
 * - Not authenticated → /login?next=<current path>
 * - Authenticated + onboarding incomplete → /empezar
 * - Authenticated + onboarding complete → render children
 */
export function AppGuard({ children }: { children: React.ReactNode }) {
  const { status, authenticated } = useOnboardingStatus();
  const location = useLocation();

  if (status === 'loading') return SKELETON;
  if (status === 'error') return ERROR_SCREEN;

  if (!authenticated) {
    const next = `${location.pathname}${location.search}`;
    return <Navigate to={`/login?next=${encodeURIComponent(next)}`} replace />;
  }

  if (status === 'not_started' || status === 'in_progress') {
    return <Navigate to="/empezar" replace />;
  }

  return <>{children}</>;
}

/**
 * Protects /empezar.
 * - Not authenticated → /signup
 * - Authenticated + completed → /hoy
 * - Authenticated + not completed → render children
 */
export function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const { status, authenticated } = useOnboardingStatus();

  if (status === 'loading') return SKELETON;
  if (status === 'error') return ERROR_SCREEN;

  if (!authenticated) {
    return <Navigate to="/signup" replace />;
  }

  if (status === 'completed') {
    return <Navigate to="/hoy" replace />;
  }

  return <>{children}</>;
}

/**
 * For /registro and /login when user is already authenticated.
 * Redirects based on onboarding status.
 */
export function useAuthRedirect(): string | null {
  const { status, authenticated } = useOnboardingStatus();
  const location = useLocation();

  if (status === 'loading') return null;
  if (!authenticated) return null;

  return destinationFor(status, returnPathFromLocation(location.search));
}
