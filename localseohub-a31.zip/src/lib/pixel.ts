declare global {
  interface Window {
    fbq?: (...args: unknown[]) => void;
  }
}

export const META_PIXEL_ID = '2022587961640258';

type Store = Pick<Storage, 'getItem' | 'setItem'>;
type Params = Record<string, string | number>;
/** eventID is accepted now so a future server-side (CAPI) copy of the same event can be deduplicated by Meta. */
export interface PixelOptions { eventId?: string }

function send(kind: 'track' | 'trackCustom', name: string, params?: Params, opts?: PixelOptions) {
  if (typeof window === 'undefined' || typeof window.fbq !== 'function') return;
  const args: unknown[] = [kind, name, params ?? {}];
  if (opts?.eventId) args.push({ eventID: opts.eventId });
  window.fbq(...args);
}

export function browserStore(): Store | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage;
  } catch {
    return null;
  }
}

/** Marks the key before firing so a re-entrant call (StrictMode, remount, second tab reload) cannot fire twice. */
export function fireOnce(key: string, fire: () => void, store: Store | null = browserStore()): boolean {
  try {
    if (store?.getItem(key)) return false;
    store?.setItem(key, '1');
  } catch {
    // storage unavailable: fire for this call only
  }
  fire();
  return true;
}

export function trackPageView() {
  send('track', 'PageView');
}

export function trackLead() {
  send('track', 'Lead');
}

export function trackCompleteRegistration(opts?: PixelOptions) {
  send('track', 'CompleteRegistration', undefined, opts);
}

export function trackActivation(opts?: PixelOptions) {
  send('trackCustom', 'Activation', undefined, opts);
}

export interface Money { value: number; currency: 'EUR' }

export function trackInitiateCheckout(money: Money, opts?: PixelOptions) {
  send('track', 'InitiateCheckout', { value: money.value, currency: money.currency }, opts);
}

export function trackPurchase(money: Money, opts?: PixelOptions) {
  send('track', 'Purchase', { value: money.value, currency: money.currency }, opts);
}
