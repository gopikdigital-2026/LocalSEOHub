import os, re, json, hashlib, zipfile, fnmatch, sys

OUT = 'localseohub-gbp02-fix02f.zip'
WORK = '.fix02f-work'
ARC = 'auditoria-a2/gbp02-fix02f/'
EXD = {'node_modules', 'dist', '.git', '.bolt', 'deliverables', WORK}
SECRET = re.compile(rb'(sk_live_[0-9A-Za-z]{10,}|sk_test_[0-9A-Za-z]{10,}|whsec_[0-9A-Za-z]{10,}|SUPABASE_SERVICE_ROLE_KEY\s*=\s*\S+|-----BEGIN [A-Z ]*PRIVATE KEY|AIza[0-9A-Za-z_\-]{30,}|GOCSPX-[0-9A-Za-z_\-]{10,}|eyJ[0-9A-Za-z_\-]{20,}\.eyJ[0-9A-Za-z_\-]{20,}\.[0-9A-Za-z_\-]{10,})')
h = lambda b: hashlib.sha256(b).hexdigest()

def skip(p):
    b = os.path.basename(p)
    return b.startswith('.env') or b.endswith('.zip') or any(fnmatch.fnmatch(b, g) for g in ['*.pem', '*.key', '*.p12', '*.pfx', 'id_rsa*'])

entries = {}
for d, ds, fs in os.walk('.'):
    ds[:] = [x for x in ds if x not in EXD]
    for f in fs:
        p = os.path.relpath(os.path.join(d, f))
        if not skip(p): entries[p] = p
for d, ds, fs in os.walk(WORK):
    for f in fs:
        p = os.path.relpath(os.path.join(d, f))
        entries[ARC + os.path.relpath(p, WORK)] = p

req = ['GBP_02_FIX02F_REPORT.md', 'GBP_02_FIX02F_TEST_REPORT.md',
       'src/features/meta-connection/__tests__/a351MetaConnection.test.ts'] + \
      [ARC + 'evidence/' + x for x in ['01-meta-guardian.log', '02-gbp-compat.log', '03-full-suite.log', '04-tsc.log',
       '05-lint.log', '06-build.log', 'phase1.json', 'phase2.json', 'repin-13.json', 'frozen-20-real.json',
       'guardian-test.diff', 'a351MetaConnection.test.before.ts', 'a351MetaConnection.test.after.ts']]
missing = [r for r in req if r not in entries]
if missing: sys.exit('missing: %s' % missing)

data = {a: open(p, 'rb').read() for a, p in sorted(entries.items())}
hits = sorted(a for a, b in data.items() if SECRET.search(b))
if '--scan' in sys.argv:
    for a in hits:
        for m in SECRET.finditer(data[a]): print(a, m.group(0)[:60])
    sys.exit(0)

integrity = {'secret_scan_hits_reviewed': hits, 'excluded_dirs': sorted(EXD - {WORK}),
             'excluded_patterns': ['.env*', '*.zip', '*.pem', '*.key', '*.p12', '*.pfx', 'id_rsa*'],
             'required_present': True, 'file_count': len(data)}
data[ARC + 'evidence/integrity.json'] = json.dumps(integrity, indent=1).encode()
manifest = {'deliverable': OUT, 'generated': '2026-11-25',
            'entries': {a: {'size': len(b), 'sha256': h(b)} for a, b in sorted(data.items())}}
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for a, b in sorted(data.items()): z.writestr(a, b)
    z.writestr('FIX02F_ZIP_MANIFEST.json', json.dumps(manifest, indent=1))
print('written', OUT, len(data) + 1, 'entries; secret hits:', hits)
