import hashlib, json, os, re, subprocess, sys, zipfile, difflib

ROOT = os.getcwd()
EV = os.path.join(ROOT, '.fix02f-work', 'evidence')
TEST = 'src/features/meta-connection/__tests__/a351MetaConnection.test.ts'
PREV_ZIP = 'deliverables/localseohub-gbp02-fix02e.zip'
GUARDIAN_HEADER = "describe('A3.5.1 · P. GBP regression: frozen files'"

REPIN = {
    'supabase/functions/gbp-oauth-start/handler.ts': 'FIX02B',
    'supabase/functions/gbp-oauth-start/index.ts': 'FIX02B',
    'supabase/functions/gbp-disconnect/handler.ts': 'FIX02B',
    'supabase/functions/gbp-disconnect/index.ts': 'FIX02B',
    'supabase/functions/gbp-sync/handler.ts': 'FIX02B',
    'supabase/functions/gbp-sync/index.ts': 'FIX02B',
    'supabase/functions/gbp-reviews/handler.ts': 'FIX02B',
    'supabase/functions/gbp-reviews/index.ts': 'FIX02B',
    'supabase/functions/gbp-recover-attempt/handler.ts': 'FIX02C',
    'supabase/functions/gbp-recover-attempt/index.ts': 'FIX02C',
    'supabase/functions/gbp-list-locations/handler.ts': 'FIX02C',
    'supabase/functions/gbp-list-locations/index.ts': 'FIX02C',
    'src/features/reality-engine/engine.ts': 'FIX02C',
}

def sha(b): return hashlib.sha256(b).hexdigest()
def fsha(p):
    with open(p, 'rb') as f: return sha(f.read())

def frozen_map(text):
    start = text.index(GUARDIAN_HEADER)
    m = re.search(r'const FROZEN[^=]*=\s*\{(.*?)\n\s*\};', text[start:], re.S)
    return dict(re.findall(r"'([^']+)':\s*'([0-9a-f]{64})'", m.group(1)))

def phase1():
    os.makedirs(EV, exist_ok=True)
    cur_bytes = open(TEST, 'rb').read()
    cur = cur_bytes.decode()
    with zipfile.ZipFile(PREV_ZIP) as z:
        name = [n for n in z.namelist() if n.endswith(TEST)][0]
        prev_bytes = z.read(name)
    prev = prev_bytes.decode()
    open(os.path.join(EV, 'a351MetaConnection.test.before.ts'), 'wb').write(prev_bytes)
    open(os.path.join(EV, 'a351MetaConnection.test.after.ts'), 'wb').write(cur_bytes)

    before, after = frozen_map(prev), frozen_map(cur)
    changed = sorted(k for k in after if before.get(k) != after[k])
    unexpected = sorted(set(changed) ^ set(REPIN))

    pl, cl = prev.splitlines(keepends=True), cur.splitlines(keepends=True)
    diff = ''.join(difflib.unified_diff(pl, cl, 'a/' + TEST, 'b/' + TEST))
    open(os.path.join(EV, 'guardian-test.diff'), 'w').write(diff)

    other = []
    sm = difflib.SequenceMatcher(a=pl, b=cl, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal': continue
        for line in pl[i1:i2] + cl[j1:j2]:
            m = re.match(r"\s*'([^']+)':\s*'([0-9a-f]{64})',?\s*$", line)
            if not m or m.group(1) not in REPIN: other.append(line.rstrip('\n'))

    all_real = [{'file': p, 'pinned': after[p], 'real': fsha(p), 'match': fsha(p) == after[p]} for p in sorted(after)]
    rows = []
    for p in sorted(REPIN):
        real = fsha(p)
        rows.append({'file': p, 'origin': REPIN[p], 'old': before[p], 'new': after[p], 'real': real,
                     'new_matches_real': real == after[p], 'old_matches_real': real == before[p]})

    result = {
        'test_file': TEST,
        'sha_before': sha(prev_bytes), 'sha_after': sha(cur_bytes),
        'before_source': PREV_ZIP + '::' + name,
        'diff_sha256': sha(diff.encode()),
        'diff_lines': diff.count('\n'),
        'frozen_entries': len(after), 'changed_entries': len(changed),
        'unexpected_changed_entries': unexpected,
        'non_hash_line_differences': other,
        'repin_all_match': all(r['new_matches_real'] for r in rows),
        'frozen_all_match': all(r['match'] for r in all_real),
    }
    result['ok'] = (not unexpected and not other and len(changed) == 13
                    and result['repin_all_match'] and result['frozen_all_match'])
    json.dump(rows, open(os.path.join(EV, 'repin-13.json'), 'w'), indent=2)
    json.dump(all_real, open(os.path.join(EV, 'frozen-20-real.json'), 'w'), indent=2)
    json.dump(result, open(os.path.join(EV, 'phase1.json'), 'w'), indent=2)
    print(json.dumps(result, indent=2))
    return result['ok']

def run(name, cmd):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    out = p.stdout + p.stderr
    open(os.path.join(EV, name + '.log'), 'w').write(f'$ {cmd}\nexit={p.returncode}\n\n' + out)
    return p.returncode, out

def phase2():
    strip = lambda s: re.sub(r'\x1b\[[0-9;]*m', '', s)
    def tests(out):
        o = strip(out)
        f = re.search(r'Test Files\s+(.*)', o); t = re.search(r'\n\s*Tests\s+(.*)', o)
        return {'files': f.group(1).strip() if f else None, 'tests': t.group(1).strip() if t else None}
    res = {}
    c, o = run('01-meta-guardian', f'npx vitest run {TEST}'); res['meta_guardian'] = {'exit': c, **tests(o)}
    c, o = run('02-gbp-compat', 'npx vitest run src/features/reality-engine'); res['gbp_compat'] = {'exit': c, **tests(o)}
    c, o = run('03-full-suite', 'npx vitest run'); res['full_suite'] = {'exit': c, **tests(o)}
    c, o = run('04-tsc', 'npx tsc --noEmit -p tsconfig.app.json'); res['tsc'] = {'exit': c, 'errors': len(re.findall(r'error TS\d+', o))}
    c, o = run('05-lint', 'npx eslint .')
    m = re.search(r'\((\d+) errors?, (\d+) warnings?\)', strip(o))
    res['lint'] = {'exit': c, 'errors': int(m.group(1)) if m else 0, 'warnings': int(m.group(2)) if m else 0}
    c, o = run('06-build', 'npm run build'); res['build'] = {'exit': c, 'ok': c == 0}
    json.dump(res, open(os.path.join(EV, 'phase2.json'), 'w'), indent=2)
    print(json.dumps(res, indent=2))

if __name__ == '__main__':
    if sys.argv[1] == '1': sys.exit(0 if phase1() else 1)
    if sys.argv[1] == '2': phase2()
