import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";
import { requirePremium } from "./entitlement.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SYSTEM_PROMPT = `Eres un Community Manager experto en viralidad local. Crea un plan de contenidos de 7 días para redes sociales. Cada día debe ser una idea de post o vídeo corto enfocada en atraer clientes de la ciudad especificada hacia el producto.

Devuelve SIEMPRE un JSON con esta estructura exacta (la clave raíz DEBE llamarse "days"):
{
  "days": [
    {
      "day": 1,
      "platform": "Instagram",
      "hooks": ["gancho 1", "gancho 2", "gancho 3"],
      "content_ideas": ["idea 1", "idea 2", "idea 3"],
      "local_hashtags": ["#hashtag1", "#hashtag2", "#hashtag3"]
    },
    ... (7 objetos en total)
  ]
}

Reglas:
- "day": número del 1 al 7
- "platform": alterna "Instagram" y "TikTok" empezando por Instagram
- "hooks": array de exactamente 3 ganchos (primera frase del post/vídeo, directa y con urgencia o curiosidad)
- "content_ideas": array de exactamente 3 ideas de contenido (2-3 frases, específicas para el producto y la ciudad)
- "local_hashtags": array de 3-5 hashtags locales (sin espacios, combinando ciudad y producto)

Usa el nombre de la ciudad de forma natural. Sé creativo, variado y accionable.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const access = await requirePremium(req, "generate-content-plan", corsHeaders);
  if (!access.ok) return access.response;

  try {
    const apiKey = Deno.env.get("LocalSEO_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const anonSupabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: userError } = await anonSupabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { product, city, platform, description } = await req.json();

    if (!product?.trim()) {
      return new Response(
        JSON.stringify({ error: "El campo 'producto' es obligatorio" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userPrompt = [
      `Producto o servicio: ${product}`,
      city ? `Ciudad / Región objetivo: ${city}` : null,
      platform ? `Plataforma principal de venta: ${platform}` : null,
      description ? `Descripción SEO del producto:\n${description}` : null,
    ]
      .filter(Boolean)
      .join("\n\n");

    const openAIRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.85,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!openAIRes.ok) {
      const errBody = await openAIRes.text();
      console.error("OpenAI error:", errBody);
      return new Response(
        JSON.stringify({ error: "Error al contactar con OpenAI", details: errBody }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const openAIData = await openAIRes.json();
    const raw = openAIData.choices?.[0]?.message?.content ?? "{}";

    let parsed: { days?: unknown[] } = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      return new Response(
        JSON.stringify({ error: "La IA devolvió un formato inválido", raw }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!Array.isArray(parsed.days) || parsed.days.length === 0) {
      // Fallback: look for any array property in the response
      const anyArray = Object.values(parsed).find(
        (v): v is unknown[] => Array.isArray(v) && v.length > 0
      );
      if (!anyArray) {
        return new Response(
          JSON.stringify({ error: "La IA no devolvió el calendario esperado", raw }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      parsed.days = anyArray;
    }

    const toArray = (val: unknown): string[] => {
      if (Array.isArray(val)) return val as string[];
      if (typeof val === "string") return (val as string).split(/[\s,]+/).filter(Boolean);
      return [];
    };

    const days = (parsed.days as Record<string, unknown>[]).map((d) => ({
      day: d.day,
      platform: d.platform,
      hooks: toArray(d.hooks ?? d.hook),
      content_ideas: toArray(d.content_ideas ?? d.content_idea),
      local_hashtags: toArray(d.local_hashtags),
    }));

    return new Response(
      JSON.stringify({ days }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Error interno del servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
