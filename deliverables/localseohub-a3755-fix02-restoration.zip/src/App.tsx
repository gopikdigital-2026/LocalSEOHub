import { lazy, Suspense, useState, useEffect, useCallback } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { returnPathFromLocation } from './app-v2/returnTo';
import AppShellV2 from './app-v2/layouts/AppShellV2';
import { useAuth } from './hooks/useAuth';
import { useOnboardingStatus } from './hooks/useOnboardingStatus';
import { AppGuard, OnboardingGuard, useAuthRedirect } from './app-v2/auth';
import { InternalGuard } from './features/internal-access/InternalGuard';
import { LoadingState } from './components/ui';
import { RESET_PASSWORD_PATH, type RecoveryLink } from './features/password-reset/recovery';
import { VERIFY_REDIRECT_PATH, type VerificationLinkProblem } from './features/email-verification/verification';

// ─── Product pages ──────────────────────────────────────────────────────────

const TodayPage = lazy(() => import('./app-v2/routes/TodayPage'));
const PlanPage = lazy(() => import('./app-v2/routes/PlanPage'));
const ExecutionPage = lazy(() => import('./features/execution/ExecutionPage'));
const BusinessProfilePage = lazy(() => import('./features/business-memory/BusinessProfilePage'));
const BusinessGoalsPage = lazy(() => import('./features/business-memory/BusinessGoalsPage'));
const BusinessMemoryPage = lazy(() => import('./features/business-memory/BusinessMemoryPage'));
const WeeklySummaryPage = lazy(() => import('./features/business-memory/WeeklySummaryPage'));
const SourceManagerPage = lazy(() => import('./features/reality-engine/SourceManager'));
const FirstValueFlow = lazy(() => import('./features/first-value/FirstValueFlow'));
const GBPCallbackPage = lazy(() => import('./features/reality-engine/GBPCallbackPage'));
const MetaCallbackPage = lazy(() => import('./features/meta-connection/MetaCallbackPage'));
const BillingPage = lazy(() => import('./features/billing/BillingPage'));
const ToolsPage = lazy(() => import('./features/tools/ToolsPage'));
const SeoGeneratorPage = lazy(() => import('./features/seo-generator/SeoGeneratorPage'));
const AdvisorPage = lazy(() => import('./features/business-advisor/AdvisorPage'));
const MapsScannerPage = lazy(() => import('./features/maps-scanner/MapsScannerPage'));
const GeoAuditPage = lazy(() => import('./features/geo-audit/GeoAuditPage'));
const DigitalTwinPage = lazy(() => import('./features/digital-twin/DigitalTwinPage'));
const CompetitorRadarPage = lazy(() => import('./features/competitor-radar/CompetitorRadarPage'));
const VoiceSimulatorPage = lazy(() => import('./features/voice-simulator/VoiceSimulatorPage'));
const ReviewsPage = lazy(() => import('./features/reviews/ReviewsPage'));
const SocialIntelligencePage = lazy(() => import('./features/social-intelligence/ui/SocialIntelligencePage'));
// Temporary internal validation harness; intentionally not linked from any navigation.
const PublicationsValidationPage = lazy(() => import('./features/publications/validation/PublicationsValidationPage'));
const ChannelAdaptationPanel = lazy(() => import('./features/channel-adaptation/ChannelAdaptationPanel'));
const ChannelReviewPanel = lazy(() => import('./features/channel-review/ChannelReviewPanel'));
const FbHarness = lazy(() => import('./features/facebook-publish/FacebookPublishHarness'));
const IgHarness = lazy(() => import('./features/instagram-publish/InstagramPublishHarness'));
const PublicationResumeProvider = lazy(() => import('./features/publication-resume/PublicationResumeProvider'));

// ─── Public pages ───────────────────────────────────────────────────────────

const LandingPage = lazy(() => import('./components/LandingPage'));
const LoginModal = lazy(() => import('./components/LoginModal'));
const ResetPasswordPage = lazy(() => import('./features/password-reset/ResetPasswordPage'));
const PrivacyPolicyPage = lazy(() => import('./features/legal/PrivacyPolicyPage'));
const TermsPage = lazy(() => import('./features/legal/TermsPage'));
const DataDeletionPage = lazy(() => import('./features/legal/DataDeletionPage'));

const SKELETON = (
  <div className="min-h-screen bg-v2-bg-primary flex items-center justify-center font-v2">
    <LoadingState message="Cargando..." />
  </div>
);

// ─── Pending business name (landing → onboarding handoff) ───────────────────

const PENDING_BIZ_KEY = 'pending_business_name';

export function getPendingBusinessName(): string | null {
  const v = sessionStorage.getItem(PENDING_BIZ_KEY);
  if (v) sessionStorage.removeItem(PENDING_BIZ_KEY);
  return v;
}

function savePendingBusinessName(name: string) {
  if (name.trim()) sessionStorage.setItem(PENDING_BIZ_KEY, name.trim());
}

// ─── / — Landing (anon only) ────────────────────────────────────────────────

function RootRoute() {
  const { status, authenticated } = useOnboardingStatus();
  const [showLogin, setShowLogin] = useState(false);
  const [loginMode, setLoginMode] = useState<'login' | 'signup'>('login');
  const [loginEmail, setLoginEmail] = useState('');

  useEffect(() => {
    const h = window.location.hash;
    if (h === '#login') { setLoginMode('login'); setShowLogin(true); }
    else if (h === '#registro') { setLoginMode('signup'); setShowLogin(true); }
  }, []);

  if (status === 'loading') return SKELETON;

  if (authenticated) {
    return <Navigate to={status === 'completed' ? '/hoy' : '/empezar'} replace />;
  }

  return (
    <Suspense fallback={null}>
      <LandingPage
        onLoginClick={(email?: string) => {
          if (email) setLoginEmail(email);
          setLoginMode('login');
          setShowLogin(true);
        }}
        onSignupClick={(businessName?: string) => {
          if (businessName) savePendingBusinessName(businessName);
          setLoginMode('signup');
          setShowLogin(true);
        }}
        onSubscribeClick={() => {
          setLoginMode('signup');
          setShowLogin(true);
        }}
      />
      {showLogin && (
        <Suspense fallback={null}>
          <LoginModal
            onClose={() => { setShowLogin(false); setLoginEmail(''); window.history.replaceState(null, '', '/'); }}
            initialMode={loginMode}
            initialEmail={loginEmail}
          />
        </Suspense>
      )}
    </Suspense>
  );
}

// ─── /signup & /login ───────────────────────────────────────────────────────

function AuthRoute({ mode, linkProblem = null }: { mode: 'login' | 'signup'; linkProblem?: VerificationLinkProblem | null }) {
  const redirect = useAuthRedirect();
  const navigate = useNavigate();
  const location = useLocation();
  const { status } = useOnboardingStatus();

  if (status === 'loading') return SKELETON;

  if (redirect) return <Navigate to={redirect} replace />;

  // After sign-in the session change re-renders this route and useAuthRedirect sends the user on.
  return (
    <Suspense fallback={null}>
      <LoginModal
        onClose={() => navigate('/')}
        onSuccess={() => {}}
        returnTo={returnPathFromLocation(location.search)}
        initialMode={mode}
        initialRecovering={mode === 'login' && new URLSearchParams(location.search).has('recuperar')}
        initialLinkProblem={linkProblem}
      />
    </Suspense>
  );
}

// ─── App ────────────────────────────────────────────────────────────────────

export default function App({ initialRecoveryLink = null, initialLinkProblem = null }: { initialRecoveryLink?: RecoveryLink | null; initialLinkProblem?: VerificationLinkProblem | null }) {
  const location = useLocation();
  const [recoveryLink, setRecoveryLink] = useState(initialRecoveryLink);
  const consumeRecoveryLink = useCallback(() => setRecoveryLink(null), []);
  const [linkProblem, setLinkProblem] = useState(initialLinkProblem);

  useEffect(() => {
    if (location.pathname !== VERIFY_REDIRECT_PATH) setLinkProblem(null);
  }, [location.pathname]);

  // A recovery link can land on another page (e.g. Supabase falls back to the Site URL);
  // route it to the reset page before the landing sends the recovered session into the app.
  if (recoveryLink && location.pathname !== RESET_PASSWORD_PATH) {
    return <Navigate to={{ pathname: RESET_PASSWORD_PATH, search: location.search, hash: location.hash }} replace />;
  }

  return (
    <Suspense fallback={SKELETON}>
      <Routes>
        {/* ── Public ── */}
        <Route path="/" element={<RootRoute />} />
        <Route path="/signup" element={<AuthRoute mode="signup" />} />
        <Route path="/login" element={<AuthRoute mode="login" linkProblem={linkProblem} />} />
        <Route path={RESET_PASSWORD_PATH} element={
          <ResetPasswordPage initialLink={recoveryLink} onLinkConsumed={consumeRecoveryLink} />
        } />
        <Route path="/privacidad" element={<PrivacyPolicyPage />} />
        <Route path="/terminos" element={<TermsPage />} />
        <Route path="/eliminar-datos" element={<DataDeletionPage />} />

        {/* ── Onboarding ── */}
        <Route path="/empezar" element={
          <OnboardingGuard>
            <Suspense fallback={SKELETON}>
              <FirstValueFlow />
            </Suspense>
          </OnboardingGuard>
        } />

        {/* ── Main app (auth + onboarding complete) ── */}
        <Route element={<AppGuard><AppShellV2 /></AppGuard>}>
          <Route path="/hoy" element={<TodayPage />} />
          <Route path="/plan" element={<PlanPage />} />
          <Route path="/herramientas" element={<ToolsPage />} />
          <Route path="/herramientas/seo" element={<SeoGeneratorPage />} />
          <Route path="/herramientas/advisor" element={<AdvisorPage />} />
          <Route path="/herramientas/maps" element={<MapsScannerPage />} />
          <Route path="/herramientas/geo" element={<GeoAuditPage />} />
          <Route path="/herramientas/twin" element={<DigitalTwinPage />} />
          <Route path="/herramientas/radar" element={<CompetitorRadarPage />} />
          <Route path="/herramientas/voice" element={<VoiceSimulatorPage />} />
          <Route path="/herramientas/resenas" element={<ReviewsPage />} />
          <Route path="/herramientas/social" element={<SocialIntelligencePage />} />
          <Route path="/informes" element={<WeeklySummaryPage />} />
          <Route path="/negocio" element={<BusinessProfilePage />} />
          <Route path="/negocio/objetivos" element={<BusinessGoalsPage />} />
          <Route path="/negocio/memoria" element={<BusinessMemoryPage />} />
          <Route path="/fuentes" element={<SourceManagerPage />} />
          <Route path="/facturacion" element={<BillingPage />} />
        </Route>

        {/* ── OAuth callbacks (auth, no shell) ── */}
        <Route path="/oauth/google-business/callback" element={
          <AppGuard>
            <Suspense fallback={SKELETON}>
              <GBPCallbackPage />
            </Suspense>
          </AppGuard>
        } />
        <Route path="/oauth/meta/callback" element={
          <AppGuard>
            <Suspense fallback={SKELETON}>
              <MetaCallbackPage />
            </Suspense>
          </AppGuard>
        } />

        <Route element={<InternalGuard><Suspense fallback={SKELETON}><PublicationResumeProvider /></Suspense></InternalGuard>}>
        <Route path="/internal/publications-validation" element={
          <AppGuard>
            <Suspense fallback={SKELETON}>
              <PublicationsValidationPage />
              <ChannelAdaptationPanel />
              <ChannelReviewPanel /><FbHarness /><IgHarness />
            </Suspense>
          </AppGuard>
        } />
        </Route>

        {/* ── Execution (auth, no shell) ── */}
        <Route path="/ejecutar/:recommendationId" element={
          <AppGuard>
            <div className="min-h-screen bg-v2-bg-primary font-v2">
              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
                <ExecutionPage />
              </div>
            </div>
          </AppGuard>
        } />

        {/* ── Legacy compatibility redirects ── */}
        <Route path="/registro" element={<Navigate to="/signup" replace />} />
        <Route path="/dashboard" element={<Navigate to="/hoy" replace />} />
        <Route path="/app-v2/*" element={<Navigate to="/hoy" replace />} />

        {/* ── Fallback ── */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
