# LocalSEOHub.io — GBP-02-FIX02F · Actualización controlada de guardianes de integridad

**Fecha:** 2026-11-25
**Estado:** COMPLETADO, detenido para auditoría independiente
**Archivo modificado (único):** `src/features/meta-connection/__tests__/a351MetaConnection.test.ts`

> **Nota de regeneración.** Una reversión del proyecto volvió a eliminar los entregables y las evidencias de FIX02F. Se han regenerado desde cero:
> - el estado "antes" del test se obtiene de la copia verificada dentro de `deliverables/localseohub-gbp02-fix02e.zip`;
> - todas las validaciones se han vuelto a ejecutar;
> - los resultados son idénticos a la entrega original (diff del test con SHA `ee2b455d5f93c7747b8cd500a6b1778dcf62a99845f3651ef23cdd536c2f36a7`).
>
> El cambio del guardián seguía aplicado en el proyecto: SHA actual `dd64157c…6fff78`.

## 1. Resumen

| Concepto | Valor |
|---|---|
| Hashes obsoletos identificados | 13 (8 de FIX02B y 5 de FIX02C) |
| Hashes actualizados | 13 |
| Otros hashes protegidos | 7, sin cambios y coincidentes con los archivos reales |
| Líneas cambiadas en el test | 13 eliminadas y 13 añadidas, todas del tipo `'ruta': 'hash',` |
| SHA-256 del test antes | `07c224a828c6128c951fd0e227ea335117ccae53b23a8a1b3be7ee587b673d81` |
| SHA-256 del test después | `dd64157c96f5b3eb59336a26d2d3f37d57f13a7e2f9918c1afb7e3336a6fff78` |
| Guardián Meta antes | 87 aprobadas y 13 fallidas de 100 |
| Guardián Meta después | 100/100 (bloque P: 22/22) |
| Suite completa | 3336/3336, 100 archivos |
| TypeScript | 20 errores (referencia: 20) |
| Lint | 47 errores y 10 avisos (referencia: 47/10) |
| Build | Correcto |

## 2. Fase 1 — Verificación previa

### 2.1 Método

Lo ejecuta y afirma el script `auditoria-a2/gbp02-fix02f/evidence.py`:

1. Extrae el test previo de `deliverables/localseohub-gbp02-fix02e.zip` y comprueba que su SHA sea `07c224…7d81`.
2. Lee el mapa `FROZEN` del bloque `A3.5.1 · P. GBP regression: frozen files` (20 rutas) antes y después.
3. Calcula el SHA-256 real de los 20 archivos.
4. Calcula el hash de cada archivo en 8 ZIP de la cadena: final-audit, fix01, fix01a, fix02a, fix02b, fix02c, fix02d y fix02e.
5. Para cada uno de los 13 archivos, afirma lo siguiente:
   - Los de FIX02B tienen el hash antiguo del guardián en el ZIP de FIX02A y el hash actual en el ZIP de FIX02B.
   - Los de FIX02C tienen el hash antiguo en el ZIP de FIX02B y el hash actual en el ZIP de FIX02C.
   - Todos conservan el hash actual en los ZIP de FIX02D y FIX02E, sin cambios posteriores no autorizados.
6. Afirma que los otros 7 archivos protegidos coinciden con su hash, que ya existía y no se toca.

Resultado: todas las afirmaciones pasan y no aparece ninguna diferencia sin justificar.

### 2.2 Tabla de linaje (resumen)

| Grupo | Hash antiguo presente en | Hash nuevo aparece en | Estable en |
|---|---|---|---|
| FIX02B (8 archivos) | ZIP de FIX02A | ZIP de FIX02B | FIX02C, FIX02D, FIX02E y el proyecto actual |
| FIX02C (5 archivos) | ZIP de FIX02B | ZIP de FIX02C | FIX02D, FIX02E y el proyecto actual |

El detalle completo por archivo y por ZIP está en `evidence/lineage.json`.

**Observación:** en el ZIP de final-audit, `gbp-sync/handler.ts` muestra una versión anterior distinta. Ese archivo ya estaba fijado desde FIX01, y esta tarea no lo trata.

### 2.3 Justificación de alcance

- **FIX02B** (negocio activo en las funciones GBP) cambió `gbp-oauth-start`, `gbp-disconnect`, `gbp-sync` y `gbp-reviews`. De cada una cambió `handler.ts` e `index.ts`.
- **FIX02C** (dependencias explícitas) cambió `gbp-recover-attempt` y `gbp-list-locations`, también `handler.ts` e `index.ts` de cada una, además de `reality-engine/engine.ts`.
- Los diffs exactos de cada archivo frente a su base están en `evidence/guardian-files.diff`: 513 líneas, con el resumen en `guardian-files-stats.json`.

## 3. Fase 2 — Los 13 hashes

| # | Archivo | Fase | SHA-256 anterior | SHA-256 posterior | Base del diff | Diff |
|---|---|---|---|---|---|---|
| 1 | `supabase/functions/gbp-oauth-start/handler.ts` | FIX02B | `991438435abdc920e98fdf830215ed63227d8d2ce697c0ff6c3220bb260130b8` | `81d01feaa42c8e01f1989b96e53780a3cc8ca0930d9bf38cd7f36ef203e4d933` | FIX02A | +22/-6 |
| 2 | `supabase/functions/gbp-oauth-start/index.ts` | FIX02B | `8cb979ce494a8ec281ec3b1035b0fa364853baf796b96a0e632ac413eb573464` | `186e6257e675dd17e598bd7215043ad2155dd0163c9b1438cfd20c9046b288a2` | FIX02A | +6/-3 |
| 3 | `supabase/functions/gbp-disconnect/handler.ts` | FIX02B | `45c1acbed37364c434b9369452d93282a809699b4a7d17bcd5fa535e35b0cf83` | `e2064c2b75165c6b521cb94f523c974b81ed913cdeb83eb12a6571fb477e2f28` | FIX02A | +11/-4 |
| 4 | `supabase/functions/gbp-disconnect/index.ts` | FIX02B | `7b28648afd40074e65a9db6d48fb417394981965ecf827edde829d507b9da948` | `457b0734e0499d3703dd78c18dcca4c1802552fcea64d0049850748257f85d55` | FIX02A | +23/-10 |
| 5 | `supabase/functions/gbp-sync/handler.ts` | FIX02B | `d71f8fde10b30e44eace976982301fc01bab3898974577cf30f612b341d7673a` | `915bedc7baa97f87a00c0b675ff7c86949f202554c067cee4ef8b2534c4aef84` | FIX02A | +18/-4 |
| 6 | `supabase/functions/gbp-sync/index.ts` | FIX02B | `fee680186b7550eeaf7903185f0a8ad6fc7866b65ff71f1ef1aa1ed9d4209ddf` | `748b7aba58828c8b481d3c2dff8f54d878cbc00bca112c38933c9a77177f8ac6` | FIX02A | +6/-3 |
| 7 | `supabase/functions/gbp-recover-attempt/handler.ts` | FIX02C | `879ec241a3605e9aa2355a92166f864f3206391c3ac7ffb5cb4111ce1b5cb660` | `8467fa461754a1c8ea8e317112adbf1cb3ea17b3893a1ba6309f42ac4cb15437` | FIX02B | +11/-4 |
| 8 | `supabase/functions/gbp-recover-attempt/index.ts` | FIX02C | `0126d8d56316b163295ee48cd2e43dcae495323f4b7444695a1e49f573b69461` | `3a0d378b6f71478b1c4c49dcb52aceced12b022ac2e10c97478b9f55e7f9b162` | FIX02B | +4/-3 |
| 9 | `supabase/functions/gbp-list-locations/handler.ts` | FIX02C | `222a8836ca24a5f4a7362d67ff36a78ed4789afde1a37e88fb2fa84743af5fc5` | `eb137ce7d5160c127a2f9b622d16f0c2eb3eaf714ca6b93c5ca1a718bbf7c543` | FIX02B | +8/-2 |
| 10 | `supabase/functions/gbp-list-locations/index.ts` | FIX02C | `20bc1c331614524766b5c578db31ee7049d3f9db1693af4803488a14c8bc1913` | `cbdc2d077463d88f9140ac5b1c1db84b9c4e3c2e998587aeef5ea032ab2a7782` | FIX02B | +11/-5 |
| 11 | `supabase/functions/gbp-reviews/handler.ts` | FIX02B | `415883be71ce38ffe72f44051f834af565babb7e27be1cc5afdc8f6ed4adfe3e` | `61e667d0f82a4e218f7a6652cb2672c2cdf553e93a167dd45992b20b25a2a16f` | FIX02A | +12/-3 |
| 12 | `supabase/functions/gbp-reviews/index.ts` | FIX02B | `19222fb038e8f115f6aba173d96510986b9ea0744e614dd890bfecf6699792ac` | `3e72f0ada835dbd464abe5ab9cd9262881f3b4c1f7880efc04b81cfa76ef5432` | FIX02A | +11/-1 |
| 13 | `src/features/reality-engine/engine.ts` | FIX02C | `46205263e3a5216b8e2e8d4c454a8af74da95398e78ea260392491e48a91ce20` | `0d1ac39b768bbe6a13e5699aa759c656a1a142f641208bd0615b53b1b381c7cb` | FIX02B | +2/-2 |

### 3.1 Hashes protegidos que no cambian (7)

| Archivo | SHA-256 (sin cambio y coincidente con el real) |
|---|---|
| `supabase/functions/gbp-oauth-callback/handler.ts` | `f1a97cb69a9fc33e8dd2da8ccaa99e74979bff474d9f17d6dbe6f07dc13a86a4` |
| `supabase/functions/gbp-oauth-callback/index.ts` | `90fc20c1f0ca22d56b991c1cd8b38c7c15125167cbae37051b9d4186bf827fae` |
| `src/features/reality-engine/GBPCallbackPage.tsx` | `ec6e9ee8c6e66866b92580042a9e2b98e084d44c56403bee459ff10ef83a5d04` |
| `src/features/reality-engine/gbpStatus.ts` | `5db8b3c8f2b5bcfc68f9226c2c6642b23f8b5301290c55341d2651237a51e4e3` |
| `src/features/reality-engine/SourceCard.tsx` | `a0535ea61b40845930935fcfefc699267aeb827dfc2d7b696e88d0fd0a9cf026` |
| `src/features/reality-engine/registry.ts` | `2186e0b5e36fa20dde9b80e7e00580331b10d47fc4d7f5ecbde022370a611b8f` |
| `src/features/reality-engine/sourceStatus.ts` | `f5d9531241a2660ffa3322acdb9ce32d7247a4a906a7d47492125fb3f01bcbf0` |

### 3.2 Diferencia exacta del test

En `evidence/guardian-test.diff` (SHA `ee2b455d5f93c7747b8cd500a6b1778dcf62a99845f3651ef23cdd536c2f36a7`):

- se eliminan 13 líneas y se añaden 13;
- todas pertenecen al mapa `FROZEN`;
- no cambian rutas, nombres, aserciones, estructura ni orden.

El script lo comprueba con una expresión regular que acepta solo pares `'ruta': 'hash',`.

## 4. Fase 3 — Validación

| Comprobación | Resultado | Registro |
|---|---|---|
| Guardián Meta (antes, copia temporal del test previo) | 87 aprobadas y 13 fallidas de 100 | `meta-guardian-before.log` |
| Guardián Meta (después) | 100/100, bloque P 22/22 | `meta-guardian.log` |
| Pruebas GBP: FIX01, FIX02B, FIX02C, a341, a3422 y gbpListLocations | 168/168 | `gbp-fix.log` |
| Suite completa | 3336/3336 en 100 archivos | `full-suite.log`, `full-suite.json` |
| TypeScript | 20 errores, todos ya existentes | `typecheck.log` |
| Lint | 47 errores y 10 avisos, todos ya existentes | `lint.log` |
| Build | Correcto | `build.log` |

La copia temporal `zzFix02fBaseline.test.ts` se borró después de usarla, y se comprobó que ya no está.

## 5. Integridad

- **Base:** `deliverables/localseohub-gbp02-fix02e.zip`.
- **Resultado:** 852 archivos del proyecto son idénticos byte a byte. El único archivo cambiado es `a351MetaConnection.test.ts`. Ningún archivo de la base falta en el proyecto.
- **Detalle:** `evidence/integrity.json`. El manifiesto con el SHA de cada entrada del ZIP es `FIX02F_ZIP_MANIFEST.json`, dentro del ZIP.

## 6. Prohibiciones respetadas

| Prohibición | Cumplimiento |
|---|---|
| Lógica de producción | Sin cambios (comprobación de integridad) |
| Otros tests | Sin cambios |
| Migraciones, índices y RLS | Sin cambios y sin llamadas a la base de datos |
| Despliegues de funciones | Ninguno |
| Publicación | Ninguna |
| Llamadas reales a Google | Ninguna |
| FIX03 | No iniciado |

## 7. Observaciones para la auditoría

- El empaquetado de las funciones Edge de Supabase sigue **NO VERIFICADO**.
- La concurrencia y el uso único del estado OAuth siguen **NO certificados**.
- Este cambio solo vuelve a alinear los guardianes con cambios ya autorizados. No valida en producción las funciones afectadas.

## 8. Entregables

- `GBP_02_FIX02F_REPORT.md` (este documento)
- `GBP_02_FIX02F_TEST_REPORT.md`
- `localseohub-gbp02-fix02f.zip`, en la raíz y en `deliverables/`, con copias idénticas
- `auditoria-a2/gbp02-fix02f/` con `evidence.py`, `package.py`, `delivery-checks.json` y `evidence/`
